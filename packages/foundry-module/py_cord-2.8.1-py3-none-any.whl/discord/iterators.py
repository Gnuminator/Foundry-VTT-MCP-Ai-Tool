"""
The MIT License (MIT)

Copyright (c) 2015-2021 Rapptz
Copyright (c) 2021-present Pycord Development

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from __future__ import annotations

import asyncio
import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    Generator,
    List,
    TypeVar,
    Union,
)

from typing_extensions import deprecated, override

from .audit_logs import AuditLogEntry
from .errors import NoMoreItems
from .object import Object
from .utils import maybe_coroutine, snowflake_time, time_snowflake

__all__ = (
    "ReactionIterator",
    "HistoryIterator",
    "AuditLogIterator",
    "GuildIterator",
    "MemberIterator",
    "ScheduledEventSubscribersIterator",
    "EntitlementIterator",
    "SubscriptionIterator",
    "MessagePinIterator",
)

if TYPE_CHECKING:
    from .abc import MessageableChannel, Snowflake
    from .guild import BanEntry, Guild
    from .http import HTTPClient
    from .member import Member
    from .message import Message, MessagePin
    from .monetization import Entitlement, Subscription
    from .scheduled_events import ScheduledEvent
    from .threads import Thread
    from .types.audit_log import AuditLog as AuditLogPayload
    from .types.guild import Guild as GuildPayload
    from .types.message import Message as MessagePayload
    from .types.message import MessagePin as MessagePinPayload
    from .types.monetization import Entitlement as EntitlementPayload
    from .types.monetization import Subscription as SubscriptionPayload
    from .types.threads import Thread as ThreadPayload
    from .types.user import PartialUser as PartialUserPayload
    from .user import User

T = TypeVar("T")
OT = TypeVar("OT")
_Func = Callable[[T], Union[OT, Awaitable[OT]]]

OLDEST_OBJECT = Object(id=0)


class _AsyncIterator(AsyncIterator[T]):
    __slots__ = ()

    async def next(self) -> T:
        raise NotImplementedError

    def get(self, **attrs: Any) -> Awaitable[T | None]:
        def predicate(elem: T):
            for attr, val in attrs.items():
                nested = attr.split("__")
                obj = elem
                for attribute in nested:
                    obj = getattr(obj, attribute)

                if obj != val:
                    return False
            return True

        return self.find(predicate)

    async def find(self, predicate: _Func[T, bool]) -> T | None:
        while True:
            try:
                elem = await self.next()
            except NoMoreItems:
                return None

            ret = await maybe_coroutine(predicate, elem)
            if ret:
                return elem

    def chunk(self, max_size: int) -> _ChunkedAsyncIterator[T]:
        if max_size <= 0:
            raise ValueError("async iterator chunk sizes must be greater than 0.")
        return _ChunkedAsyncIterator(self, max_size)

    def map(self, func: _Func[T, OT]) -> _MappedAsyncIterator[OT]:
        return _MappedAsyncIterator(self, func)

    def filter(self, predicate: _Func[T, bool]) -> _FilteredAsyncIterator[T]:
        return _FilteredAsyncIterator(self, predicate)

    async def flatten(self) -> list[T]:
        return [element async for element in self]

    async def __anext__(self) -> T:
        try:
            return await self.next()
        except NoMoreItems:
            raise StopAsyncIteration()


def _identity(x):
    return x


class _ChunkedAsyncIterator(_AsyncIterator[List[T]]):
    def __init__(self, iterator, max_size):
        self.iterator = iterator
        self.max_size = max_size

    async def next(self) -> list[T]:
        ret: list[T] = []
        n = 0
        while n < self.max_size:
            try:
                item = await self.iterator.next()
            except NoMoreItems:
                if ret:
                    return ret
                raise
            else:
                ret.append(item)
                n += 1
        return ret


class _MappedAsyncIterator(_AsyncIterator[T]):
    def __init__(self, iterator, func):
        self.iterator = iterator
        self.func = func

    async def next(self) -> T:
        # this raises NoMoreItems and will propagate appropriately
        item = await self.iterator.next()
        return await maybe_coroutine(self.func, item)


class _FilteredAsyncIterator(_AsyncIterator[T]):
    def __init__(self, iterator, predicate):
        self.iterator = iterator

        if predicate is None:
            predicate = _identity

        self.predicate = predicate

    async def next(self) -> T:
        getter = self.iterator.next
        pred = self.predicate
        while True:
            # propagate NoMoreItems similar to _MappedAsyncIterator
            item = await getter()
            ret = await maybe_coroutine(pred, item)
            if ret:
                return item


class ReactionIterator(_AsyncIterator[Union["User", "Member"]]):
    def __init__(self, message, emoji, limit=100, after=None, type=None):
        self.message = message
        self.limit = limit
        self.after = after
        self.type = type
        state = message._state
        self.getter = state.http.get_reaction_users
        self.state = state
        self.emoji = emoji
        self.guild = message.guild
        self.channel_id = message.channel.id
        self.users = asyncio.Queue()

    async def next(self) -> User | Member:
        if self.users.empty():
            await self.fill_users()

        try:
            return self.users.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    async def fill_users(self):
        # this is a hack because >circular imports<
        from .user import User

        if self.limit > 0:
            retrieve = min(self.limit, 100)

            after = self.after.id if self.after else None
            data: list[PartialUserPayload] = await self.getter(
                self.channel_id,
                self.message.id,
                self.emoji,
                retrieve,
                after=after,
                type=self.type,
            )

            if data:
                self.limit -= retrieve
                self.after = Object(id=int(data[-1]["id"]))

            for element in reversed(data):
                if self.guild is None or isinstance(self.guild, Object):
                    await self.users.put(User(state=self.state, data=element))
                else:
                    member_id = int(element["id"])
                    member = self.guild.get_member(member_id)
                    if member is not None:
                        await self.users.put(member)
                    else:
                        await self.users.put(User(state=self.state, data=element))


class VoteIterator(_AsyncIterator[Union["User", "Member"]]):
    def __init__(self, message, answer, limit=100, after=None):
        self.message = message
        self.limit = limit
        self.after = after
        state = message._state
        self.getter = state.http.get_answer_voters
        self.state = state
        self.answer = answer
        self.guild = message.guild
        self.channel_id = message.channel.id
        self.users = asyncio.Queue()

    async def next(self) -> User | Member:
        if self.users.empty():
            await self.fill_users()

        try:
            return self.users.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    async def fill_users(self):
        # import here to prevent circular imports
        from .user import User

        if self.limit > 0:
            retrieve = min(self.limit, 100)

            after = self.after.id if self.after else None
            req = await self.getter(
                self.channel_id,
                self.message.id,
                self.answer.id,
                retrieve,
                after=after,
            )
            data: list[PartialUserPayload] = req.get("users", [])

            if data:
                self.limit -= retrieve
                self.after = Object(id=int(data[-1]["id"]))

            for element in reversed(data):
                if self.guild is None or isinstance(self.guild, Object):
                    await self.users.put(User(state=self.state, data=element))
                else:
                    member_id = int(element["id"])
                    member = self.guild.get_member(member_id)
                    if member is not None:
                        await self.users.put(member)
                    else:
                        await self.users.put(User(state=self.state, data=element))


class HistoryIterator(_AsyncIterator["Message"]):
    """Iterator for receiving a channel's message history.

    The messages endpoint has two behaviours we care about here:
    If ``before`` is specified, the messages endpoint returns the `limit`
    newest messages before ``before``, sorted with newest first. For filling over
    100 messages, update the ``before`` parameter to the oldest message received.
    Messages will be returned in order by time.
    If ``after`` is specified, it returns the ``limit`` oldest messages after
    ``after``, sorted with newest first. For filling over 100 messages, update the
    ``after`` parameter to the newest message received. If messages are not
    reversed, they will be out of order (99-0, 199-100, so on)

    A note that if both ``before`` and ``after`` are specified, ``before`` is ignored by the
    messages endpoint.

    Parameters
    ----------
    messageable: :class:`abc.Messageable`
        Messageable class to retrieve message history from.
    limit: :class:`int`
        Maximum number of messages to retrieve
    before: Optional[Union[:class:`abc.Snowflake`, :class:`datetime.datetime`]]
        Message before which all messages must be.
    after: Optional[Union[:class:`abc.Snowflake`, :class:`datetime.datetime`]]
        Message after which all messages must be.
    around: Optional[Union[:class:`abc.Snowflake`, :class:`datetime.datetime`]]
        Message around which all messages must be. Limit max 101. Note that if
        limit is an even number, this will return at most limit+1 messages.
    oldest_first: Optional[:class:`bool`]
        If set to ``True``, return messages in oldest->newest order. Defaults to
        ``True`` if `after` is specified, otherwise ``False``.
    """

    def __init__(
        self,
        messageable,
        limit,
        before=None,
        after=None,
        around=None,
        oldest_first=None,
    ):
        if isinstance(before, datetime.datetime):
            before = Object(id=time_snowflake(before, high=False))
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))
        if isinstance(around, datetime.datetime):
            around = Object(id=time_snowflake(around))

        self.reverse = after is not None if oldest_first is None else oldest_first
        self.messageable = messageable
        self.limit = limit
        self.before = before
        self.after = after or OLDEST_OBJECT
        self.around = around

        self._filter = None  # message dict -> bool

        self.state = self.messageable._state
        self.logs_from = self.state.http.logs_from
        self.messages = asyncio.Queue()

        if self.around:
            if self.limit is None:
                raise ValueError("history does not support around with limit=None")
            if self.limit > 101:
                raise ValueError(
                    "history max limit 101 when specifying around parameter"
                )
            elif self.limit == 101:
                self.limit = 100  # Thanks discord

            self._retrieve_messages = self._retrieve_messages_around_strategy  # type: ignore
            if self.before and self.after:
                self._filter = lambda m: self.after.id < int(m["id"]) < self.before.id
            elif self.before:
                self._filter = lambda m: int(m["id"]) < self.before.id
            elif self.after:
                self._filter = lambda m: self.after.id < int(m["id"])
        elif self.reverse:
            self._retrieve_messages = self._retrieve_messages_after_strategy  # type: ignore
            if self.before:
                self._filter = lambda m: int(m["id"]) < self.before.id
        else:
            self._retrieve_messages = self._retrieve_messages_before_strategy  # type: ignore
            if self.after and self.after != OLDEST_OBJECT:
                self._filter = lambda m: int(m["id"]) > self.after.id

    async def next(self) -> Message:
        if self.messages.empty():
            await self.fill_messages()

        try:
            return self.messages.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self) -> bool:
        l = self.limit
        if l is None or l > 100:
            r = 100
        else:
            r = l
        self.retrieve = r
        return r > 0

    async def fill_messages(self):
        if not hasattr(self, "channel"):
            # do the required set up
            channel = await self.messageable._get_channel()
            self.channel = channel

        if self._get_retrieve():
            data = await self._retrieve_messages(self.retrieve)
            if len(data) < 100:
                self.limit = 0  # terminate the infinite loop

            if self.reverse:
                data = reversed(data)
            if self._filter:
                data = filter(self._filter, data)

            channel = self.channel
            for element in data:
                await self.messages.put(
                    self.state.create_message(channel=channel, data=element)
                )

    async def _retrieve_messages(self, retrieve: int) -> list[MessagePayload]:
        """Retrieve messages and update next parameters."""
        raise NotImplementedError

    async def _retrieve_messages_before_strategy(
        self, retrieve: int
    ) -> list[MessagePayload]:
        """Retrieve messages using before parameter."""
        before = self.before.id if self.before else None
        data: list[MessagePayload] = await self.logs_from(
            self.channel.id, retrieve, before=before
        )
        if len(data):
            if self.limit is not None:
                self.limit -= retrieve
            self.before = Object(id=int(data[-1]["id"]))
        return data

    async def _retrieve_messages_after_strategy(
        self, retrieve: int
    ) -> list[MessagePayload]:
        """Retrieve messages using after parameter."""
        after = self.after.id if self.after else None
        data: list[MessagePayload] = await self.logs_from(
            self.channel.id, retrieve, after=after
        )
        if len(data):
            if self.limit is not None:
                self.limit -= retrieve
            self.after = Object(id=int(data[0]["id"]))
        return data

    async def _retrieve_messages_around_strategy(
        self, retrieve: int
    ) -> list[MessagePayload]:
        """Retrieve messages using around parameter."""
        if self.around:
            around = self.around.id if self.around else None
            data: list[MessagePayload] = await self.logs_from(
                self.channel.id, retrieve, around=around
            )
            self.around = None
            return data
        return []


class AuditLogIterator(_AsyncIterator["AuditLogEntry"]):
    def __init__(
        self,
        guild,
        limit=None,
        before=None,
        after=None,
        user_id=None,
        action_type=None,
    ):
        if isinstance(before, datetime.datetime):
            before = Object(id=time_snowflake(before, high=False))
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))

        self.guild = guild
        self.loop = guild._state.loop
        self.request = guild._state.http.get_audit_logs
        self.limit = limit
        self.before = before
        self.user_id = user_id
        self.action_type = action_type
        self.after = after
        self._users = {}
        self._state = guild._state
        self.entries = asyncio.Queue()

    async def _retrieve_entries(self, retrieve):
        if not self._get_retrieve():
            return
        before = self.before.id if self.before else None
        after = self.after.id if self.after else None
        data: AuditLogPayload = await self.request(
            self.guild.id,
            limit=retrieve,
            user_id=self.user_id,
            action_type=self.action_type,
            before=before,
            after=after,
        )

        entries = data.get("audit_log_entries", [])
        # if ONLY after is passed and NOT before, Discord reverses the sort to oldest first.
        if len(data) and entries:
            if self.limit is not None:
                self.limit -= retrieve
            if self.before or not self.after:
                self.before = Object(id=int(entries[-1]["id"]))
            if self.after and not self.before:
                self.after = Object(id=int(entries[-1]["id"]))
        return data.get("users", []), entries

    async def next(self) -> AuditLogEntry:
        if self.entries.empty():
            await self._fill()

        try:
            return self.entries.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 100:
            r = 100
        else:
            r = l
        self.retrieve = r
        return r > 0

    async def _fill(self):
        from .user import User

        if self._get_retrieve():
            users, data = await self._retrieve_entries(self.retrieve)
            if len(data) < 100:
                self.limit = 0  # terminate the infinite loop

            for user in users:
                u = User(data=user, state=self._state)
                self._users[u.id] = u

            for element in data:
                await self.entries.put(
                    AuditLogEntry(data=element, users=self._users, guild=self.guild)
                )


class GuildIterator(_AsyncIterator["Guild"]):
    """Iterator for receiving the client's guilds.

    The guilds endpoint has the same two behaviours as described
    in :class:`HistoryIterator`:
    If ``before`` is specified, the guilds endpoint returns the ``limit``
    newest guilds before ``before``, sorted with newest first. For filling over
    100 guilds, update the ``before`` parameter to the oldest guild received.
    Guilds will be returned in order by time.
    If `after` is specified, it returns the ``limit`` oldest guilds after ``after``,
    sorted with newest first. For filling over 100 guilds, update the ``after``
    parameter to the newest guild received, If guilds are not reversed, they
    will be out of order (99-0, 199-100, so on)

    Not that if both ``before`` and ``after`` are specified, ``before`` is ignored by the
    guilds endpoint.

    Parameters
    ----------
    bot: :class:`discord.Client`
        The client to retrieve the guilds from.
    limit: :class:`int`
        Maximum number of guilds to retrieve.
    before: Optional[Union[:class:`abc.Snowflake`, :class:`datetime.datetime`]]
        Object before which all guilds must be.
    after: Optional[Union[:class:`abc.Snowflake`, :class:`datetime.datetime`]]
        Object after which all guilds must be.
    with_counts: :class:`bool`
        Whether to include member count information in guilds. This fills the
        :attr:`.Guild.approximate_member_count` and :attr:`.Guild.approximate_presence_count`
        fields.
        Defaults to ``True``.
    """

    def __init__(self, bot, limit, before=None, after=None, with_counts=True):
        if isinstance(before, datetime.datetime):
            before = Object(id=time_snowflake(before, high=False))
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))

        self.bot = bot
        self.limit = limit
        self.before = before
        self.after = after
        self.with_counts = with_counts

        self._filter = None

        self.state = self.bot._connection
        self.get_guilds = self.bot.http.get_guilds
        self.guilds = asyncio.Queue()

        if self.before and self.after:
            self._retrieve_guilds = self._retrieve_guilds_before_strategy  # type: ignore
            self._filter = lambda m: int(m["id"]) > self.after.id
        elif self.after:
            self._retrieve_guilds = self._retrieve_guilds_after_strategy  # type: ignore
        else:
            self._retrieve_guilds = self._retrieve_guilds_before_strategy  # type: ignore

    async def next(self) -> Guild:
        if self.guilds.empty():
            await self.fill_guilds()

        try:
            return self.guilds.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 100:
            r = 100
        else:
            r = l
        self.retrieve = r
        return r > 0

    def create_guild(self, data):
        from .guild import Guild

        return Guild(state=self.state, data=data)

    async def fill_guilds(self):
        if self._get_retrieve():
            data = await self._retrieve_guilds(self.retrieve)
            if self.limit is None or len(data) < 100:
                self.limit = 0

            if self._filter:
                data = filter(self._filter, data)

            for element in data:
                await self.guilds.put(self.create_guild(element))

    async def _retrieve_guilds(self, retrieve) -> list[Guild]:
        """Retrieve guilds and update next parameters."""
        raise NotImplementedError

    async def _retrieve_guilds_before_strategy(self, retrieve):
        """Retrieve guilds using before parameter."""
        before = self.before.id if self.before else None
        data: list[GuildPayload] = await self.get_guilds(
            retrieve, before=before, with_counts=self.with_counts
        )
        if len(data):
            if self.limit is not None:
                self.limit -= retrieve
            self.before = Object(id=int(data[-1]["id"]))
        return data

    async def _retrieve_guilds_after_strategy(self, retrieve):
        """Retrieve guilds using after parameter."""
        after = self.after.id if self.after else None
        data: list[GuildPayload] = await self.get_guilds(
            retrieve, after=after, with_counts=self.with_counts
        )
        if len(data):
            if self.limit is not None:
                self.limit -= retrieve
            self.after = Object(id=int(data[0]["id"]))
        return data


class MemberIterator(_AsyncIterator["Member"]):
    def __init__(self, guild, limit=1000, after=None):
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))

        self.guild = guild
        self.limit = limit
        self.after = after or OLDEST_OBJECT

        self.state = self.guild._state
        self.get_members = self.state.http.get_members
        self.members = asyncio.Queue()

    async def next(self) -> Member:
        if self.members.empty():
            await self.fill_members()

        try:
            return self.members.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 1000:
            r = 1000
        else:
            r = l
        self.retrieve = r
        return r > 0

    async def fill_members(self):
        if not self._get_retrieve():
            return
        after = self.after.id if self.after else None
        data = await self.get_members(self.guild.id, self.retrieve, after)
        if not data:
            # no data, terminate
            return

        if len(data) < 1000:
            self.limit = 0  # terminate loop

        self.after = Object(id=int(data[-1]["user"]["id"]))

        for element in reversed(data):
            await self.members.put(self.create_member(element))

    def create_member(self, data):
        from .member import Member

        return Member(data=data, guild=self.guild, state=self.state)


class BanIterator(_AsyncIterator["BanEntry"]):
    def __init__(self, guild, limit=None, before=None, after=None):
        self.guild = guild
        self.limit = limit
        self.after = after
        self.before = before

        self.state = self.guild._state
        self.get_bans = self.state.http.get_bans
        self.bans = asyncio.Queue()

    async def next(self) -> BanEntry:
        if self.bans.empty():
            await self.fill_bans()

        try:
            return self.bans.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 1000:
            r = 1000
        else:
            r = l
        self.retrieve = r
        return r > 0

    async def fill_bans(self):
        if not self._get_retrieve():
            return
        before = self.before.id if self.before else None
        after = self.after.id if self.after else None
        data = await self.get_bans(self.guild.id, self.retrieve, before, after)
        if not data:
            # no data, terminate
            return
        if self.limit:
            self.limit -= self.retrieve

        if len(data) < 1000:
            self.limit = 0  # terminate loop

        self.after = Object(id=int(data[-1]["user"]["id"]))

        for element in reversed(data):
            await self.bans.put(self.create_ban(element))

    def create_ban(self, data):
        from .guild import BanEntry
        from .user import User

        return BanEntry(
            reason=data["reason"], user=User(state=self.state, data=data["user"])
        )


class ArchivedThreadIterator(_AsyncIterator["Thread"]):
    def __init__(
        self,
        channel_id: int,
        guild: Guild,
        limit: int | None,
        joined: bool,
        private: bool,
        before: Snowflake | datetime.datetime | None = None,
    ):
        self.channel_id = channel_id
        self.guild = guild
        self.limit = limit
        self.joined = joined
        self.private = private
        self.http = guild._state.http

        if joined and not private:
            raise ValueError("Cannot iterate over joined public archived threads")

        self.before: str | None
        if before is None:
            self.before = None
        elif isinstance(before, datetime.datetime):
            if joined:
                self.before = str(time_snowflake(before, high=False))
            else:
                self.before = before.isoformat()
        else:
            if joined:
                self.before = str(before.id)
            else:
                self.before = snowflake_time(before.id).isoformat()

        self.update_before: Callable[[ThreadPayload], str] = self.get_archive_timestamp

        if joined:
            self.endpoint = self.http.get_joined_private_archived_threads
            self.update_before = self.get_thread_id
        elif private:
            self.endpoint = self.http.get_private_archived_threads
        else:
            self.endpoint = self.http.get_public_archived_threads

        self.queue: asyncio.Queue[Thread] = asyncio.Queue()
        self.has_more: bool = True

    async def next(self) -> Thread:
        if self.queue.empty():
            await self.fill_queue()

        try:
            return self.queue.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    @staticmethod
    def get_archive_timestamp(data: ThreadPayload) -> str:
        return data["thread_metadata"]["archive_timestamp"]

    @staticmethod
    def get_thread_id(data: ThreadPayload) -> str:
        return data["id"]  # type: ignore

    async def fill_queue(self) -> None:
        if not self.has_more:
            raise NoMoreItems()

        limit = 50 if self.limit is None else min(self.limit, 50)
        data = await self.endpoint(self.channel_id, before=self.before, limit=limit)

        # This stuff is obviously WIP because 'members' is always empty
        threads: list[ThreadPayload] = data.get("threads", [])
        for d in reversed(threads):
            self.queue.put_nowait(self.create_thread(d))

        self.has_more = data.get("has_more", False)
        if self.limit is not None:
            self.limit -= len(threads)
            if self.limit <= 0:
                self.has_more = False

        if self.has_more:
            self.before = self.update_before(threads[-1])

    def create_thread(self, data: ThreadPayload) -> Thread:
        from .threads import Thread

        return Thread(guild=self.guild, state=self.guild._state, data=data)


class ScheduledEventSubscribersIterator(_AsyncIterator[Union["User", "Member"]]):
    def __init__(
        self,
        event: ScheduledEvent,
        limit: int | None,
        with_member: bool = False,
        before: datetime.datetime | int | None = None,
        after: datetime.datetime | int | None = None,
    ):
        if isinstance(before, datetime.datetime):
            before = Object(id=time_snowflake(before, high=False))
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))

        self.event = event
        self.limit = limit
        self.with_member = with_member
        self.before = before
        self.after = after

        self.subscribers = asyncio.Queue()
        self.get_subscribers = self.event._state.http.get_scheduled_event_users

    async def next(self) -> User | Member:
        if self.subscribers.empty():
            await self.fill_subs()

        try:
            return self.subscribers.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 100:
            r = 100
        else:
            r = l
        self.retrieve = r
        return r > 0

    def member_from_payload(self, data):
        from .member import Member

        user = data.pop("user")

        member = data.pop("member")
        member["user"] = user

        return Member(data=member, guild=self.event.guild, state=self.event._state)

    def user_from_payload(self, data):
        from .user import User

        user = data.pop("user")

        return User(state=self.event._state, data=user)

    async def fill_subs(self):
        if not self._get_retrieve():
            return

        before = self.before.id if self.before else None
        after = self.after.id if self.after else None
        data = await self.get_subscribers(
            guild_id=self.event.guild.id,
            event_id=self.event.id,
            limit=self.retrieve,
            with_member=self.with_member,
            before=before,
            after=after,
        )

        data_length = len(data)
        if data_length < self.retrieve:
            self.limit = 0
        elif data_length > 0:
            if self.limit:
                self.limit -= self.retrieve
            self.after = Object(id=int(data[-1]["user_id"]))

        for element in reversed(data):
            if "member" in element:
                await self.subscribers.put(self.member_from_payload(element))
            else:
                await self.subscribers.put(self.user_from_payload(element))


class EntitlementIterator(_AsyncIterator["Entitlement"]):
    def __init__(
        self,
        state,
        user_id: int | None = None,
        sku_ids: list[int] | None = None,
        before: datetime.datetime | Object | None = None,
        after: datetime.datetime | Object | None = None,
        limit: int | None = None,
        guild_id: int | None = None,
        exclude_ended: bool | None = None,
    ):
        self.user_id = user_id
        self.sku_ids = sku_ids

        if isinstance(before, datetime.datetime):
            before = Object(id=time_snowflake(before, high=False))
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))

        self.before = before
        self.after = after
        self.limit = limit
        self.guild_id = guild_id
        self.exclude_ended = exclude_ended

        self._filter = None

        if self.before and self.after:
            self._retrieve_entitlements = self._retrieve_entitlements_before_strategy
            self._filter = lambda e: int(e["id"]) > self.after.id
        elif self.after:
            self._retrieve_entitlements = self._retrieve_entitlements_after_strategy
        else:
            self._retrieve_entitlements = self._retrieve_entitlements_before_strategy

        self.state = state
        self.get_entitlements = state.http.list_entitlements
        self.entitlements = asyncio.Queue()

    async def next(self) -> Entitlement:
        if self.entitlements.empty():
            await self.fill_entitlements()

        try:
            return self.entitlements.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 100:
            r = 100
        else:
            r = l
        self.retrieve = r
        return r > 0

    def create_entitlement(self, data) -> Entitlement:
        from .monetization import Entitlement

        return Entitlement(data=data, state=self.state)

    async def fill_entitlements(self):
        if not self._get_retrieve():
            return

        data = await self._retrieve_entitlements(self.retrieve)

        if self._filter:
            data = list(filter(self._filter, data))

        if len(data) < 100:
            self.limit = 0  # terminate loop

        for element in data:
            await self.entitlements.put(self.create_entitlement(element))

    async def _retrieve_entitlements(self, retrieve) -> list[EntitlementPayload]:
        """Retrieve entitlements and update next parameters."""
        raise NotImplementedError

    async def _retrieve_entitlements_before_strategy(
        self, retrieve: int
    ) -> list[EntitlementPayload]:
        """Retrieve entitlements using before parameter."""
        before = self.before.id if self.before else None
        data = await self.get_entitlements(
            self.state.application_id,
            before=before,
            limit=retrieve,
            user_id=self.user_id,
            guild_id=self.guild_id,
            sku_ids=self.sku_ids,
            exclude_ended=self.exclude_ended,
        )
        if data:
            if self.limit is not None:
                self.limit -= retrieve
            self.before = Object(id=int(data[-1]["id"]))
        return data

    async def _retrieve_entitlements_after_strategy(
        self, retrieve: int
    ) -> list[EntitlementPayload]:
        """Retrieve entitlements using after parameter."""
        after = self.after.id if self.after else None
        data = await self.get_entitlements(
            self.state.application_id,
            after=after,
            limit=retrieve,
            user_id=self.user_id,
            guild_id=self.guild_id,
            sku_ids=self.sku_ids,
            exclude_ended=self.exclude_ended,
        )
        if data:
            if self.limit is not None:
                self.limit -= retrieve
            self.after = Object(id=int(data[-1]["id"]))
        return data


class SubscriptionIterator(_AsyncIterator["Subscription"]):
    def __init__(
        self,
        state,
        sku_id: int,
        limit: int = None,
        before: datetime.datetime | None = None,
        after: datetime.datetime | None = None,
        user_id: int | None = None,
    ):
        if isinstance(before, datetime.datetime):
            before = Object(id=time_snowflake(before, high=False))
        if isinstance(after, datetime.datetime):
            after = Object(id=time_snowflake(after, high=True))

        self.state = state
        self.sku_id = sku_id
        self.limit = limit
        self.before = before
        self.after = after
        self.user_id = user_id

        self._filter = None

        self.get_subscriptions = state.http.list_sku_subscriptions
        self.subscriptions = asyncio.Queue()

        if self.before and self.after:
            self._retrieve_subscriptions = self._retrieve_subscriptions_before_strategy
            self._filter = lambda m: int(m["id"]) > self.after.id
        elif self.after:
            self._retrieve_subscriptions = self._retrieve_subscriptions_after_strategy
        else:
            self._retrieve_subscriptions = self._retrieve_subscriptions_before_strategy

    async def next(self) -> Guild:
        if self.subscriptions.empty():
            await self.fill_subscriptions()

        try:
            return self.subscriptions.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    def _get_retrieve(self):
        l = self.limit
        if l is None or l > 100:
            r = 100
        else:
            r = l
        self.retrieve = r
        return r > 0

    def create_subscription(self, data) -> Subscription:
        from .monetization import Subscription

        return Subscription(state=self.state, data=data)

    async def fill_subscriptions(self):
        if self._get_retrieve():
            data = await self._retrieve_subscriptions(self.retrieve)
            if self.limit is None or len(data) < 100:
                self.limit = 0

            if self._filter:
                data = filter(self._filter, data)

            for element in data:
                await self.subscriptions.put(self.create_subscription(element))

    async def _retrieve_subscriptions(self, retrieve) -> list[SubscriptionPayload]:
        raise NotImplementedError

    async def _retrieve_subscriptions_before_strategy(self, retrieve):
        before = self.before.id if self.before else None
        data: list[SubscriptionPayload] = await self.get_subscriptions(
            self.sku_id,
            limit=retrieve,
            before=before,
            user_id=self.user_id,
        )
        if len(data):
            if self.limit is not None:
                self.limit -= retrieve
            self.before = Object(id=int(data[-1]["id"]))
        return data

    async def _retrieve_subscriptions_after_strategy(self, retrieve):
        after = self.after.id if self.after else None
        data: list[SubscriptionPayload] = await self.get_subscriptions(
            self.sku_id,
            limit=retrieve,
            after=after,
            user_id=self.user_id,
        )
        if len(data):
            if self.limit is not None:
                self.limit -= retrieve
            self.after = Object(id=int(data[0]["id"]))
        return data


class MessagePinIterator(_AsyncIterator["MessagePin"]):
    def __init__(
        self,
        channel: MessageableChannel,
        limit: int | None,
        before: Snowflake | datetime.datetime | None = None,
    ):
        self._channel: MessageableChannel = channel
        self.channel: MessageableChannel | Object | None = None

        self.limit: int | None = limit
        self.http: HTTPClient = (
            channel._state.http  # pyright: ignore[reportPrivateUsage]
        )

        self.before: str | None
        if before is None:
            self.before = None
        elif isinstance(before, datetime.datetime):
            self.before = before.isoformat()
        else:
            self.before = snowflake_time(before.id).isoformat()

        self.update_before: Callable[[MessagePinPayload], str] = self.get_last_pinned

        self.queue: asyncio.Queue[MessagePin] = asyncio.Queue()
        self.has_more: bool = True

    @override
    async def next(self) -> MessagePin:
        if self.queue.empty():
            await self.fill_queue()

        try:
            return self.queue.get_nowait()
        except asyncio.QueueEmpty:
            raise NoMoreItems()

    @staticmethod
    def get_last_pinned(data: MessagePinPayload) -> str:
        return data["pinned_at"]

    async def fill_queue(self) -> None:
        if not self.has_more:
            raise NoMoreItems()

        if self.channel is None:
            channel = (
                await self._channel._get_channel()  # pyright: ignore[reportPrivateUsage]
            )
            self.channel = channel

        limit = 50 if self.limit is None else min(self.limit, 50)
        data = await self.http.pins_from(
            self.channel.id, before=self.before, limit=limit
        )

        pins: list[MessagePinPayload] = data.get("items", [])
        for d in pins:
            self.queue.put_nowait(self.create_pin(d))

        self.has_more = data.get("has_more", False)
        if self.limit is not None:
            self.limit -= len(pins)
            if self.limit <= 0:
                self.has_more = False

        if self.has_more:
            self.before = self.update_before(pins[-1])

    def create_pin(self, data: MessagePinPayload) -> MessagePin:
        from .message import MessagePin

        if self.channel is None:
            raise RuntimeError("Channel is None, cannot create pin")

        if isinstance(self.channel, Object):
            raise RuntimeError("Cannot create pin for Object channel")

        return MessagePin(
            state=self.channel._state,  # pyright: ignore[reportPrivateUsage]
            channel=self.channel,
            data=data,
        )

    async def retrieve_inner(self) -> list[Message]:
        pins = await self.flatten()
        return [p.message for p in pins]

    @deprecated(
        "Messageable.pins() returning a list of Message is deprecated since version 2.7 and will be removed in 2.9."
        + " See the documentation of Messageable.pins() for more information."
    )
    def __await__(self) -> Generator[Any, Any, list[Message]]:
        return self.retrieve_inner().__await__()

"""
discord.voice.packets
~~~~~~~~~~~~~~~~~~~~~

Sink packet handlers.
:copyright: (c) 2015-2021 Rapptz & 2021-present Pycord Development
:license: MIT, see LICENSE for more details.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .core import Packet
from .rtp import (
    FakePacket,
    ReceiverReportPacket,
    RTCPPacket,
    RTPPacket,
    SenderReportPacket,
    SilencePacket,
)

if TYPE_CHECKING:
    from discord import Member, User

__all__ = (
    "Packet",
    "RTPPacket",
    "RTCPPacket",
    "FakePacket",
    "ReceiverReportPacket",
    "SenderReportPacket",
    "SilencePacket",
    "VoiceData",
)


class VoiceData:
    """Represents an audio data from a source.

    .. versionadded:: 2.7

    Attributes
    ----------
    packet: :class:`~discord.sinks.Packet`
        The packet this source data contains.
    source: :class:`~discord.User` | :class:`~discord.Member` | None
        The user that emitted this audio source.
    pcm: :class:`bytes`
        The PCM bytes of this source.
    """

    def __init__(
        self, packet: Packet, source: User | Member | None, *, pcm: bytes | None = None
    ) -> None:
        self.packet: Packet = packet
        self.source: User | Member | None = source
        self.pcm: bytes = pcm if pcm else b""

    @property
    def opus(self) -> bytes | None:
        return self.packet.decrypted_data
